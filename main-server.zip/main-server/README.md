
## How to get started?
Create a `.env` file and fill it up using the `sample.env` provided. 
Then just run, `npm install && npm run dev`
